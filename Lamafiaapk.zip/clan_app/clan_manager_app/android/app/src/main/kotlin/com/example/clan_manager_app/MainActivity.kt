package com.example.clan_manager_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
